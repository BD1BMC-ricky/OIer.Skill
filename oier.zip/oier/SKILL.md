---
name: oier
description: 以中国信息学奥赛选手（OIer）的真实码风编写 C++ 代码。当用户要求写算法题、竞赛题、洛谷/Codeforces/AtCoder/NOIP/CSP/NOI 题解代码，或明确要求"OI 风格""竞赛码风""像 OIer 一样写代码"时，必须使用本 skill。凡是涉及数据结构、图论、DP、字符串等算法题的 C++ 代码编写、重构或改写为竞赛风格的请求，都应参考本 skill 而非默认的工程化代码风格。
---

# OIer 码风指南

本 skill 描述中国信息学竞赛选手（OIer）编写代码的真实习惯。OI 代码是赛时的一次性代码：不需要团队协作、不需要长期维护，追求的是**写得快、看得清（对自己而言）、跑得对**。因此它和工程代码的取向完全不同——工程风格的长命名、防御式注释、接口抽象在这里都是负担。写出来的代码应该让一个真正的 OIer 看了觉得"这就是我们写的东西"，而不是"这是 AI 生成的工程代码套了个竞赛壳"。

## 一、语言与整体框架

- 一律使用 C++（C++14/17 均可）。
- 头文件只写一行万能头：`#include <bits/stdc++.h>`，紧跟 `using namespace std;`。不要分别引入 `<iostream>`、`<vector>` 等标准头，也不要写 `std::` 前缀。
- `main` 函数的最后一行**必须**是 `return 0;`，没有例外。
- 常见的开头惯用写法（按需选用，不必全上）：
  - `typedef long long ll;` 或 `using ll = long long;`
  - `const int N = 1e5 + 5;`（数组上限/常量习惯命名为 `N`、`M`、`MAXN`，用 `1e5 + 5` 这类写法）
  - 涉及大量 cin/cout 时开头写 `ios::sync_with_stdio(false); cin.tie(0);`

### `#define int long long` + `signed main()` 搭配

当题目中**所有（或绝大多数）int 变量都需要 long long** 时（求和会爆 int、乘法会爆 int、数据范围到 1e18 等），OIer 常直接在开头写：

```cpp
#define int long long
```

此时 `main` 的返回类型不能再写 `int`（会被宏替换成 `long long main` 导致编译错误），所以配套写成 `signed main()`。这对搭配是绑定出现的：见到 `#define int long long` 就必须是 `signed main()`，结尾照样 `return 0;`。

使用判断：只有个别变量需要 long long 时，用 `ll` 单独声明那几个即可，不必全局替换；需要 long long 的变量遍布全程序时才用这个宏，一劳永逸且防止漏开 ll 挂分。这是工程上绝不允许、但 OI 圈完全正常且广泛存在的写法。

## 二、注释：能不写就不写

OIer 几乎不写注释。代码是写给自己看的，变量名和结构本身就是全部说明。只在以下场合才可能出现注释：

1. **确实难懂的关键一步**：一句话点到为止，如 `// 差分`、`// 注意开ll`。
2. **被注释掉的调试输出**（见第三节）。
3. **情绪宣泄**：调试极其痛苦、被卡常、被出题人阴间数据折磨时，真实 OIer 的代码里偶尔会出现 `//FuckCCF`、`//fuck this problem`、`//调了3h` 这类宣泄性注释，这是 OI 圈的正常文化现象。生成代码时**默认不要主动加**这类内容；只有当用户明确要求"最真实的码风"或要求模拟调试痕迹时，可以在艰难的调试位置极少量地出现，不针对任何真实个人。

绝对不要写的东西：函数级 doxygen 注释、`// 读入数据`、`// 输出答案` 这种解释显而易见操作的注释、大段算法原理讲解。如果用户需要讲解，讲解写在代码块外面的正文里，不要污染代码。

## 三、调试输出的痕迹

这是 OIer 代码的一大特征：写题时会插入 `cerr` 或 `printf` 调试语句打印中间变量，AC 前后把它们**注释掉而不是删掉**（万一还要再调）。当用户要求"真实的、带调试痕迹的码风"时，可以在关键位置保留一两行注释掉的调试语句：

```cpp
// cerr << "i=" << i << " f=" << f[i] << "\n";
```

也包括注释掉的 `freopen`：

```cpp
// freopen("data.in", "r", stdin);
```

默认（用户只是要一份题解代码）时可以不带这些痕迹，保持干净；但如果带上，必须是注释掉的状态。

## 四、排版与空白

- **不出现空行**，或最多在头部声明区与函数之间、以及少数逻辑段落之间留一个空行。绝不出现连续空行，绝不在函数内部随手空行分段。
- 二元运算符两侧加空格（`a + b`、`i <= n`、`x = y`），逗号后加空格；但不要为了对齐插入多余空格。一元运算符、`++`/`--`、下标、成员访问不加空格。
- 缩进必须整洁一致（4 空格或 Tab 均可，全文统一），嵌套层级清晰。OI 代码可以密，但不能乱——密而整齐是关键。
- 一行一般只放一个语句；但短小相关的语句（如 `l = 1, r = n;` 或读入 `cin >> n >> m;`）合并在一行是正常的。

## 五、大括号：能省则省，用则单独成行

- `if`/`else`/`for`/`while` 的语句体只有一条语句时，**不打大括号**，直接换行缩进：

```cpp
for (int i = 1; i <= n; i++)
    if (a[i] > mx)
        mx = a[i];
```

- 必须用大括号时（多条语句），**所有大括号一律单独成行**（Allman 风格）：左大括号独占一行，与所属语句的缩进对齐；右大括号同样独占一行，与左大括号对齐。函数、`main`、`struct`、`if`/`for`/`while` 的括号体全部遵守，全文统一：

```cpp
void solve()
{
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        sum += a[i];
    }
}
```

- **没有例外**：不要把左大括号跟在行尾（K&R），也不要把整个块压缩到一行（如 `if (x < 0) { x = -x; f = 1; }` 是错误写法，应拆开换行或省略括号逐句缩进）。

## 六、布尔值一律写 0 和 1

不使用 `true` / `false` 字面量，统一写 `1` / `0`：

```cpp
vis[u] = 1;
bool flag = 0;
if (!check(mid)) return 0;
```

这与 OI 中标记数组和标记变量的整体用法一致（`memset(vis, 0, sizeof(vis))` 清零、`vis[u] = 1` 打标记），返回布尔的函数同样返回 `0` / `1`。声明类型仍可以用 `bool`，只是赋值和返回值不用 true/false。

## 七、变量声明位置

- 全局量（数组、n、m、答案等）统一声明在文件头部，紧跟头文件和常量之后。OI 中大数组开全局是常识（栈空间不够 + 自动清零）。
- 循环变量在 `for` 头部独立声明并初始化：`for (int i = 1; i <= n; i++)`。
- 只在某个语句块内有用的临时变量，就在那个块内声明，不要提前。

## 八、函数与结构

- 函数定义直接写在 `main` 之前，按调用顺序或依赖顺序排列，**不写函数原型**。
- 相关数据打包时用 `struct`（现代 OIer 的 struct 越来越多），成员直接 public，不写 class、不写封装、不写构造函数（除非确实方便，如 `Node(int x, int y): x(x), y(y) {}` 这种简短形式可以）。
- 需要自定义排序时，写全局 `cmp` 函数或在 struct 内重载 `operator<`，两者都是地道写法。

## 九、容器与 STL

- **优先使用 `vector` 而不是裸数组**，尤其是图的邻接表：`vector<int> g[N];` 或 `vector<vector<int>> g(n + 1);`。定长且性能敏感的场合（如 DP 数组）保留全局数组也正常。
- 大胆使用 STL：`sort`、`lower_bound`、`priority_queue`、`map`、`set`、`pair`、`__gcd` 等。
- 遍历容器优先用 range-for：`for (auto v : g[u])`、`for (auto &[x, y] : mp)`（C++17 结构化绑定也是现代 OIer 常用的）。
- `pair` 的 first/second 直接用，或 `auto [d, u] = pq.top();`。

## 十、命名习惯

- 短。单字母和双三字母为主：`n, m, k, q, u, v, w, x, y, l, r, mid, ans, res, cnt, sum, mx, mn, pos, tot`。
- 约定俗成的名字：DP 数组叫 `f` 或 `dp`，输入数组叫 `a`、`b`，图叫 `g` 或 `e`，访问标记叫 `vis`，父亲叫 `fa`，深度叫 `dep`，树状数组常叫 `c` 或 `tr`，线段树节点数组叫 `t` 或 `tr`。
- 函数名同样简短：`dfs, bfs, solve, check, calc, add, query, update, build, pushup, pushdown, getf/find`（并查集）。
- 绝不出现 `calculateMaximumSubarraySum`、`inputArray`、`isVisited` 这种工程式长命名。

## 十一、完整示例

以下是一份符合上述全部习惯的示例（洛谷风格的单源最短路）：

```cpp
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;
int n, m, s;
vector<pair<int, int>> g[N];
ll dis[N];
bool vis[N];
void dijkstra(int s)
{
    memset(dis, 0x3f, sizeof(dis));
    priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<>> pq;
    dis[s] = 0;
    pq.push({0, s});
    while (!pq.empty())
    {
        auto [d, u] = pq.top(); pq.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        // cerr << "u=" << u << " d=" << d << "\n";
        for (auto [v, w] : g[u])
            if (dis[u] + w < dis[v])
            {
                dis[v] = dis[u] + w;
                pq.push({dis[v], v});
            }
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> n >> m >> s;
    for (int i = 1; i <= m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        g[u].push_back({v, w});
    }
    dijkstra(s);
    for (int i = 1; i <= n; i++)
        cout << dis[i] << " \n"[i == n];
    return 0;
}
```

注意这份代码体现的特征：万能头 + using namespace std、全局声明区、无原型、无空行、单语句不打括号、大括号一律单独成行、`vis[u] = 1` 而非 true、range-for + 结构化绑定、注释掉的 cerr、短命名、`" \n"[i == n]` 这种 OI 圈常见小技巧、结尾 `return 0;`。

## 十二、反模式清单（一票否决）

生成的代码若出现以下任何一条，就不是 OI 码风，必须改掉：

- 分开 include 多个标准头 / 使用 `std::` 前缀
- 工程式长命名、驼峰变量名
- 每几行一个解释性注释，或函数头注释块
- 左大括号跟在行尾，或整个语句块压缩在一行
- 出现 `true` / `false` 字面量
- 函数原型 + 定义分离
- class + private/public 封装、getter/setter
- 大量空行分段
- `main` 结尾没有 `return 0;`
- 用 `new`/`delete` 手动管理内存（OI 中几乎不出现）
- 异常处理 try/catch、输入合法性校验（题目保证数据合法，不需要防御）

## 十三、与用户交互的原则

- 用户只说"写个题解/代码"：给干净版（可以不带调试痕迹和宣泄注释），其余习惯全部遵守。
- 用户要求"最真实/带调试痕迹的码风"：加入注释掉的 cerr/freopen，艰难位置可极少量出现宣泄注释。
- 用户有自己的码风偏好（如"我用 Tab"/"我大括号跟行尾"）：以用户偏好为准，本 skill 提供默认值。
- 讲解和复杂度分析写在代码块外，代码保持纯净。
